# mypackage

This library was created as an example of how publish my own Python package.

# How to install

Will add this later...